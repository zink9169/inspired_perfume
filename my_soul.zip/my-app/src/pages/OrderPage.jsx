// src/pages/OrderPage.jsx
import React from "react";
import OrderForm from "../components/Orders/OrderForm";

const OrderPage = () => {
  return <OrderForm />;
};

export default OrderPage;
